# examplepackage/__init__.py

def greet(name):
    return f"Hello, {name}!"

